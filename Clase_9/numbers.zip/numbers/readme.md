
En esta carpeta están las imágenes de los dígitos con los que se realiza la Tarea 8 (archivo: RiveraRodrigo_T08.ipynb).

Las imágenes J_{}.jpg , donde las llaves se sustituyen con un dígito entre 0 y 9, son las que se emplean para probar el modelo de clasificación entrenado.

Las imágenes B_7_2.jpg , B_7_7.jpg y B_7_9.jpg son las que se emplean para comparar la predicción del modelo de clasificación. Consisten de un dígito 7 (distinto al de J_7.jpg) en el que en cada imagen el mismo dígito solo presenta un desplazamiento horizontal.
